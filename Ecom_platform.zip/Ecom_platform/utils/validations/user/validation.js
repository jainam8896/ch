const { body, query } = require("express-validator");

const registerValidator = [
  body("name").notEmpty().withMessage("Name is required"),
  body("email").notEmpty().withMessage("Email is required"),
  body("email").isEmail().withMessage("Not a valid e-mail address"),
  body("age").notEmpty().withMessage("Age is required"),
  body("age")
    .isInt({ min: 18, max: 120 })
    .withMessage("Please Enter Valid Age"),
  body("address").notEmpty().withMessage("Address Is required"),
  body("profileimage")
    .custom((value, { req }) => {
      if (
        req.file.mimetype === "image/jpg" ||
        req.file.mimetype === "image/jpeg" ||
        req.file.mimetype === "image/png"
      ) {
        return true;
      } else {
        return false;
      }
    })
    .withMessage("Please upload jpg, png, or jpeg file"),
  body("password")
    .isStrongPassword({
      minLength: 6,
      minUppercase: 1,
      minLowercase: 1,
      minNumber: 1,
    })
    .withMessage(
      "Password must be grater than 6 character, and contain atleast one uppercase, atleast one lower case letter, and one number, and one special character"
    ),
  body("password_confirmation").custom((value, { req }) => {
    console.log("password_confirmation: ", value);
    if (value !== req.body.password) throw new Error("password doesn't match");
    return true;
  }),
];

const loginValidator = [
  body("email").notEmpty().withMessage("Email is required"),
  body("password").notEmpty().withMessage("Password is Required"),
];

const changePasswordValidator = [
  body("currentPassword")
    .notEmpty()
    .withMessage("Current Password Is Required"),
  body("newPassword")
    .isStrongPassword({
      minLength: 6,
      minUppercase: 1,
      minLowercase: 1,
      minNumber: 1,
    })
    .withMessage(
      "Password must be grater than 6 character, and contain atleast one uppercase, atleast one lower case letter, and one number, and one special character"
    ),
  body("confirmPassword").custom((value, { req }) => {
    console.log("confirmPassword: ", value);
    if (value !== req.body.newPassword)
      throw new Error("New password And Confirm Password doesn't match");
    return true;
  }),
];

const forgetPasswordValidator = [
  body("email").notEmpty().withMessage("Email is required"),
];

const resetPasswordValidator = [
  body("newPassword")
    .isStrongPassword({
      minLength: 6,
      minUppercase: 1,
      minLowercase: 1,
      minNumber: 1,
    })
    .withMessage(
      "Password must be grater than 6 character, and contain atleast one uppercase, atleast one lower case letter, and one number, and one special character"
    ),
  query("token").notEmpty().withMessage("Token not found"),
  body("confirmPassword")
    .custom((value, { req }) => {
      return value === req.body.newPassword;
    })
    .withMessage("Passwords do not match"),
];

module.exports = {
  registerValidator,
  loginValidator,
  changePasswordValidator,
  forgetPasswordValidator,
  resetPasswordValidator,
};
