const Product = require("../../models/Product");

//Update category
const updateProduct = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      productName,
      productDescription,
      productPrice,
      productQty,
      categoryId,
    } = req.body;
    const updateProduct = await Product.findByIdAndUpdate(id, {
      $set: {
        productName: productName,
        productDescription: productDescription,
        productPrice: productPrice,
        productQty: productQty,
        categoryId: categoryId,
      },
    });
    if (!updateProduct) {
      res.status(404).send({ status: "failed", message: "Product Not Found" });
    }
    await updateProduct.save();
    res
      .status(200)
      .send({ status: "success", message: "Product Updated Successfully" });
  } catch (error) {
    res.json(error);
  }
};

module.exports = updateProduct;
