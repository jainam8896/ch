const Category = require("../../models/Category");

//Update category
const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, parentId } = req.body;
    const updateCategory = await Category.findByIdAndUpdate(id, {
      $set: {
        name: name,
        parentId: parentId,
      },
    });
    if (!updateCategory) {
      res.status(404).send({ status: "failed", message: "Category Not Found" });
    }
    await updateCategory.save();
    res
      .status(200)
      .send({ status: "success", message: "Category Updated Successfully" });
  } catch (error) {
    res.json(error);
  }
};

module.exports = updateCategory;
