const User = require("../../models/User");
const jwt = require("jsonwebtoken");
const sendPasswordMail = require("../../helper/sendEmail");

const forgetPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const userData = await User.findOne({ email: email });
    if (!userData) {
      return res.status(404).json("User With This Email Doest Not Exist");
    }
    const token = jwt.sign({ _id: userData._id }, process.env.JWT_SECRET_KEY, {
      expiresIn: "5m",
    });
    userData.token = token;
    await userData.save();
    await sendPasswordMail(userData.name, userData.email, token);
    // return "Password reset email has been send.....please check your email";
    return res
      .status(200)
      .json({ status: "success", message: "Password reset email has been send"});
  } catch (error) {
    res.json(error.message);
  }
};

module.exports = forgetPassword;


