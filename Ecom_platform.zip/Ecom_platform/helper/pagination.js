// const pagination = async (req, res) => {
//   {
//       options: {
//           popuate: [
//               {
//                   path: 'comments',
//                   select: ['']
//               },
//           ],
//           select: [],
//           pagination: true,
//           page: 1,
//           limit: 2
//           //order: {field: 'ASC|DESC'}
//       },
//       query: {

//       },
//       search: {
//           keys: ['title', 'qty'],
//           value: ''
//       }
// }

const paginate = async(params, modal) => {

    


    const docs = await model.find();
    return docs;
};

module.exports = paginate;
